﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API_LETA.Models
{
    public class LinckRecords
    {
        public int Id { get; set; }
        public string CreateTime { get; set; }
        public string Url { get; set; }
        public int OriginalUrl { get; set; }
        public string Title { get; set; }
        public string Note { get; set; }
        public int Lang { get; set; }
        public int Category { get; set; }
        public int Type { get; set; }
    }
}
