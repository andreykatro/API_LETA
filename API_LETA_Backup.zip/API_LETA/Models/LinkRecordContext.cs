﻿using Microsoft.EntityFrameworkCore;

namespace API_LETA.Models
{
    public class LinkRecordContext : DbContext
    {
        public DbSet<Category> Categories { get; set; }

        public LinkRecordContext(DbContextOptions<LinkRecordContext> options) : base(options) { }

        //protected override void OnModelCreating(ModelBuilder builder)
        //{
        //    builder.Entity<Category>().HasKey(m => m.Id);
        //    base.OnModelCreating(builder);
        //}
    }
}
