﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using API_LETA.Repositories;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace API_LETA.Models
{
    [Route("api/[controller]")]
    public class LinkRecordController : Controller
    {
        private readonly ICategoryRepository _categoryRepository;
        // GET: api/values
       
        public LinkRecordController(LinkRecordContext context)
        {
            _categoryRepository = new CategoryRepository(context);
        }
        [HttpGet]
        public IEnumerable<Category> Get()
        {
            return _categoryRepository.GetAll();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
