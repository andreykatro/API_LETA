﻿using API_LETA.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API_LETA.Repositories
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly LinkRecordContext _context;

        public CategoryRepository(LinkRecordContext context)
        {
            _context = context;
        }

        public List<Category> GetAll()
        {
            return _context.Categories.ToList();
        }
    }
}
