﻿using API_LETA.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API_LETA.Repositories
{
    interface ICategoryRepository
    {
        List<Category> GetAll();
    }
}
